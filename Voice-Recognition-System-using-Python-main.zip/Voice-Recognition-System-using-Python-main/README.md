# Voice-Recognition-System-using-Python
This project is made using Python module named Speech Recognition.  It can convert user voice into text in real time using the Google API. User can use other API which they are comfortable with.  I have used Google API as it was free and doesn't require any login
